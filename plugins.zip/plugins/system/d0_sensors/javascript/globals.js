var recargame = true;
var reloadtime = 2000;