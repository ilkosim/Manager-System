#!/bin/sh -e
sleep 1m
udevadm trigger
sleep 1m
wvdial
