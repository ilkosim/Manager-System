//<![CDATA[

$(document).ready(function(){
  load_interface();
});
function load_interface()
{
	var section=$('#section').val();
    var plugin=$('#plugin').val();
    var interval=$('#interval').val();
	submit_data="section="+section+"&plugin="+plugin+"&type=startBtDaemon";
    $.ajax({
        type: "POST",
        url: "index.php",
        data: submit_data,
        success: function(datos){
            if(datos == '1')
			{
               $("#daemonStatus").html("<div id='dRunning'></div> <span> <b>Eth0 UP</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Running'></div> <span> <b>Eth1 UP</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Running'></div> <span> <b>Eth2 UP</b></span>");
            }
			else if(datos == '2')
			{
               $("#daemonStatus").html("<div id='dRunning'></div> <span> <b>Eth0 UP</b></span>");
               $("#Eth1Status").html("<div id='Eth1Stopped'></div> <span> <b>Eth1 Down</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Stopped'></div> <span> <b>Eth2 Down</b></span>");
            }
			else if(datos == '3')
			{
               $("#daemonStatus").html("<div id='dStopped'></div> <span> <b>Eth0 Down</b></span>");
               $("#Eth1Status").html("<div id='Eth1Stopped'></div> <span> <b>Eth1 Down</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Running'></div> <span> <b>Eth2 UP</b></span>");
            }
			else if(datos == '4')
			{
               $("#daemonStatus").html("<div id='dStopped'></div> <span> <b>Eth0 Down</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Running'></div> <span> <b>Eth1 UP</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Stopped'></div> <span> <b>Eth2 Down</b></span>");
			}
			else if(datos == '5')
			{
               $("#daemonStatus").html("<div id='dStopped'></div> <span> <b>Eth0 Down</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Running'></div> <span> <b>Eth1 UP</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Running'></div> <span> <b>Eth2 UP</b></span>");
            }
			else if(datos == '6')
			{
               $("#daemonStatus").html("<div id='dRunning'></div> <span> <b>Eth0 UP</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Running'></div> <span> <b>Eth1 UP</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Stopped'></div> <span> <b>Eth2 Down</b></span>");
            }
			else if(datos == '7')
			{
               $("#daemonStatus").html("<div id='dRunning'></div> <span> <b>Eth0 UP</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Stopped'></div> <span> <b>Eth1 Down</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Running'></div> <span> <b>Eth2 UP</b></span>");
            }
			else if(datos == '8')
			{
               $("#daemonStatus").html("<div id='dStopped'></div> <span> <b>Eth0 Down</b></span>");
			   $("#Eth1Status").html("<div id='Eth1Stopped'></div> <span> <b>Eth1 Down</b></span>");
			   $("#Eth2Status").html("<div id='Eth2Stopped'></div> <span> <b>Eth2 Down</b></span>");
			}
              setTimeout( function()
              {
                load_interface()
              }, interval*1000);
        }
    });
}
//]]>