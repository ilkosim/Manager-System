<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */
function check_interfaces()
{
    global $url_plugin;
    global $section;
    global $plugin;
    $list='<div class="title">Ports status</div>';
	$list.='<div>
           <input type="hidden" id="plugin" value="'.$plugin.'" />
           <input type="hidden" id="section" value="'.$section.'" />
		   <input type="hidden" id="interval" value="5" />
           </div>';
    $list.='<div id="plugin_content">';
    $list.='<form id="eth" name="eth">
                <table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';
	$list.='<tr><td colspan="1" rowspan="1">';
	$list.= "<div id='daemonStatus'>";
		if (exec("cat /sys/class/net/eth0/operstate") == 'up')
		{
		$list.= '<div id="dRunning"></div> <span> <b>Eth0 UP</b></span>';
		}
		elseif (exec("cat /sys/class/net/eth0/operstate") == 'down')
		{
		$list.= '<div id="dStopped"></div> <span> <b>Eth0 Down</b></span>';
		}
		else
		{
		$list.= '<b>Problem</b> - <b>killall</b>';
		}
		$list.= "</div>";
	$list.="</td>\n";
//==========================================================================
	$list.= "<td><div id='Eth1Status'>";
		if (exec("cat /sys/class/net/eth1/operstate") == 'up')
		{
		$list.= '<div id="Eth1Running"></div> <span> <b>Eth1 UP</b></span>';
		}
		elseif (exec("cat /sys/class/net/eth1/operstate") == 'down')
		{
		$list.= '<div id="Eth1Stopped"></div> <span> <b>Eth1 Down</b></span>';
		}
		else
		{
		$list.= '<b>Problem</b> - <b>killall</b>';
		}
		$list.= "</div>";
	$list.="</td>\n";
//==========================================================================
	$list.= "<td><div id='Eth2Status'>";
		if (exec("cat /sys/class/net/eth2/operstate") == 'up')
		{
		$list.= '<div id="Eth2Running"></div> <span> <b>Eth2 UP</b></span>';
		}
		elseif (exec("cat /sys/class/net/eth2/operstate") == 'down')
		{
		$list.= '<div id="Eth2Stopped"></div> <span> <b>Eth2 Down</b></span>';
		}
		else
		{
		$list.= '<b>Problem</b> - <b>killall</b>';
		}
		$list.= "</div>";
	$list.="</td>\n";
//===========================================================================
	$list.= "<td><div id='WiFiStatus'>";
		if (exec("cat /sys/class/net/wlan0/operstate") == 'up')
		{
		$list.= '<div id="WiFiRunning"></div> <span> <b>WiFi UP</b></span>';
		}
		elseif (exec("cat /sys/class/net/wlan0/operstate") == 'down')
		{
		$list.= '<div id="WiFiStopped"></div> <span> <b>WiFi Down</b></span>';
		}
		else
		{
		$list.= '<b>Problem</b> - <b>killall</b>';
		}
		$list.= "</div>";
	$list.="</td>\n";
//===========================================================================
	$list.= "<td><div id='GStatus'>";
        if (exec("cat /sys/class/net/lte0/operstate") == 'up')
        {
        $list.= '<div id="GRunning"></div> <span> <b>4G UP</b></span>';
        }
        elseif (exec("cat /sys/class/net/lte0/operstate") == 'down')
        {
        $list.= '<div id="GStopped"></div> <span> <b>4G Down</b></span>';
        }
        else
        {
        $list.= '<b>Problem</b> - <b>killall</b>';
        }
        $list.= "</div>";
	$list.="</td></tr>\n";
	$list.='</tbody></table></form>';
	return $list;
}

?>
