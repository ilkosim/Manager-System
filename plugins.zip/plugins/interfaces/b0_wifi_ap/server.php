<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */

// Predefined variables:
// $section contains the section folder name.
// echo "section=".$section."<br>";
// $plugin contains the plugin folder name.
// echo "plugin=".$plugin."<br>";
// $section and $plugin can be used to make a link to this plugin by just reference
// echo "<a href=\"index.php?section=$section&plugin=$plugin\">This plugin</a>"."<br>";
// $base_plugin contains the path that must be used as start to includes for
// plugin includes that need the local path.
// example: include_once $base_plugin.'php/my_include.php';
// echo "base_plugin=".$base_plugin."<br>";
// $url_plugin contains the url base that must be used to include html items
// such as images.
// example: <img src="'.url_plugin.'images/my_image.png">
// echo "url_plugin=".$url_plugin."<br>";
// $API_core contains the path to the core API folder.
// example: include_once $API_core.'is_active.php';
// echo "API_core=".$API_core."<br>";

// Plugin server produced data will returned to the ajax call that made the
// request.
include_once $API_core.'complex_ajax_return_functions.php';
include_once $API_core.'json_api.php';
include_once $API_core.'form_fields_check.php';
include_once $API_core.'save_interfaces_new.php';
include_once $API_core.'parser_interfaces.php';
include_once $API_core.'modify_mac_filter.php';
include_once $API_core.'auto_code_generators.php';
include_once $base_plugin.'php/display_mac_filter.php';
include_once $base_plugin.'php/display_wifi_info.php';
//response_additem("return", '<pre>'.print_r($_POST,true).'</pre>');
if ($_POST['type']=="complex")
{
    $post_data=jsondecode($_POST['form_fields']);

        $fields_check_types = Array (
            'address'  => Array ('ms_ip','ms_mandatory'),
            'netmask'  => Array ('ms_ip','ms_mandatory'),
            'DNS1'  => Array ('ms_ip','ms_mandatory'),
            'DNS2'  => Array ('ms_ip','ms_mandatory'),
            'essid' => Array ('ms_mandatory'),
            'dhcp_start_wlan0' => Array ('ms_ip','ms_mandatory'),
            'dhcp_end_wlan0' => Array ('ms_ip','ms_mandatory'),
            'dhcp_expire_wlan0' => Array ('ms_numerical','ms_mandatory')
            );
        if(are_form_fields_valid ($post_data, $fields_check_types))
        {
    		saveInterfaces($_POST['interface'],$post_data,"/etc/network/interfaces.d/".$_POST['interface'].".conf","/etc/network/interfaces.d/".$_POST['interface'].".conf");
			save_hostapd($post_data, "/etc/hostapd/hostapd.".$_POST['interface'].".conf");
            save_dnsmasq($post_data);
			restart_interface($_POST['interface']);
			restart_hostapd ("etc/hostapd/hostapd.".$_POST['interface'].".conf");
//            response_additem("script", 'alert("Data saved.");data_changed=false;');
			response_additem("script", 'endnotify()');
			response_additem("script", 'notify("save", "Data saved.<br><br>Restart the machine to take effect.")');
			response_additem("script", 'fadenotify()');
        }
    response_return();
}
/* ------------------------------------------------------------------------ */
include_once $API_core.'conf_file.php';
include_once $base_plugin.'php/paths.php';
/* ------------------------------------------------------------------------ */
function execute ($cmd)
/* ------------------------------------------------------------------------ */
{
    //global $output;
    exec ("sudo ".$cmd, $return);
    //$output = array_merge ($output, $return); // DEBUG LOG
}
/* ------------------------------------------------------------------------ */

function save_msg ($msg)
/* ------------------------------------------------------------------------ */
{
    //response_additem ("html", "<fieldset><h2>'.$msg.'</h2></fieldset>" ,"output");
    response_additem ("script", "alert('".$msg."')");
}
/* ------------------------------------------------------------------------ */
function error_msg ($msg)
/* ------------------------------------------------------------------------ */
{
    //response_additem ("html", "<fieldset><h2>'.$msg.'</h2></fieldset>" ,"output");
    response_additem ("script", "alert('".$msg."')");
}
/* ------------------------------------------------------------------------ */
function restart_hostapd ($hostapd_file)
{
    exec ("sudo ps ax | grep ".$hostapd_file." | grep -v grep | awk '{print $1;}'", $pids);
    if ( count($pids) > 0 )
    {
        execute('kill -1 '.$pids[0]);
    } 
	else 
	{
        execute('/usr/sbin/hostapd -B '.$hostapd_file);
    }
}
/* ------------------------------------------------------------------------ */
function restart_interface ($iface)
{
    execute('ifdown '.$iface);
    execute('ifup '.$iface.' >/dev/null 2>&1 &');
}
/* ------------------------------------------------------------------------ */
function save_hostapd($post_data, $hostapd_file)//, $file="/etc/network/interfaces.d/wlan0.conf")
{
    global $paths;
    global $API_core;
	global $base_plugin;

    $writepath=$base_plugin.'data/hostapd_skeleton';
    $fp=fopen($writepath,"w");

    fwrite($fp,"interface=wlan0\n");
    fwrite($fp,"driver=nl80211\n");
    fwrite($fp,"logger_syslog=-1\n");
    fwrite($fp,"logger_syslog_level=2\n");
    fwrite($fp,"logger_stdout=-1\n");
    fwrite($fp,"logger_stdout_level=2\n");
    fwrite($fp,"debug=4\n");
	fwrite($fp,"ctrl_interface=/var/run/hostapd.wlan0\n");
	fwrite($fp,"ctrl_interface_group=0\n");
	fwrite($fp,"country_code=".$post_data['country']."\n");
//	fwrite($fp,"ieee80211d=1\n");
//	fwrite($fp,"ieee80211h=1\n");
//	fwrite($fp,"ieee80211w=1\n");
    if (isset ($post_data['hide']))
	{
        fwrite($fp,"ignore_broadcast_ssid=1\n");
	}
	else 
	{
		fwrite($fp,"ignore_broadcast_ssid=0\n");
	}
    if (trim($post_data['mode-abg']) == '1')
	{
        fwrite($fp,"channel=".$post_data['channel2']."\n");
		fwrite($fp,"hw_mode=b\n");
	}
    elseif (trim($post_data['mode-abg']) == '2')
	{
        fwrite($fp,"channel=".$post_data['channel2']."\n");
		fwrite($fp,"hw_mode=g\n");
	}
	elseif (trim($post_data['mode-abg']) == '3')
	{
		fwrite($fp,"channel=".$post_data['channel5']."\n");
        fwrite($fp,"hw_mode=a\n");
	}
	elseif ((trim($post_data['mode-abg']) == '4')&&(trim($post_data['freq']) == '5'))
	{
		fwrite($fp,"channel=".$post_data['channel5']."\n");
        fwrite($fp,"hw_mode=a\n");
	}
	elseif ((trim($post_data['mode-abg']) == '4')&&(trim($post_data['freq']) == '2'))
	{
		fwrite($fp,"channel=".$post_data['channel2']."\n");
        fwrite($fp,"hw_mode=g\n");
	}
    fwrite($fp,"macaddr_acl=0\n");
	fwrite($fp,"auth_algs=3\n");
	fwrite($fp,"eapol_key_index_workaround=0\n");
	fwrite($fp,"eap_server=0\n");
	fwrite($fp,"wpa=3\n");
	fwrite($fp,"ssid=".$post_data['essid']."\n");
    fwrite($fp,"wpa_passphrase=".$post_data['psk_pass']."\n");
	fwrite($fp,"wpa_key_mgmt=WPA-PSK\n");
	fwrite($fp,"wpa_pairwise=TKIP\n");
	fwrite($fp,"rsn_pairwise=CCMP\n");
    if (trim($post_data['mode-abg']) == '4')
	{
        fwrite($fp,"ieee80211n=1\n");
		fwrite($fp,"wme_enabled=1\n");
		fwrite($fp,"ht_capab=[HT40-][HT40+][SHORT-GI-40][TX-STBC][RX-STBC1][DSSS_CCK-40]\n");
	}
	else 
	{
		fwrite($fp,"ieee80211n=0\n");
		fwrite($fp,"wme_enabled=0\n");
	}
    if (trim($post_data['mode-abg']) == '3')
	{
		fwrite($fp,"ieee80211n=1\n");
		fwrite($fp,"wme_enabled=1\n");
		fwrite($fp,"ht_capab=[HT40-][HT40+][SHORT-GI-40][TX-STBC][RX-STBC1][DSSS_CCK-40]\n");
		fwrite($fp,"\n");
        fwrite($fp,"ieee80211ac=1\n");
		fwrite($fp,"vht_oper_chwidth=1\n");
		fwrite($fp,"vht_capab=[MAX-MPDU-11454][RXLDPC][SHORT-GI-80][TX-STBC-2BY1][RX-STBC-1][MAX-A-MPDU-LEN-EXP7][RX-ANTENNA-PATTERN][TX-ANTENNA-PATTERN]\n");
		fwrite($fp,"vht_oper_centr_freq_seg0_idx=".strval($post_data['channel5']+6)."\n");
	}
    fclose($fp);
	exec('sudo cp '.$base_plugin."data/hostapd_skeleton ".$hostapd_file);//etc/hostapd/hostapd_wlan0.conf.conf");
}
/* ------------------------------------------------------------------------ */
function save_dnsmasq($post_data, $file="/etc/dnsmasq.more.conf")
{
    global $base_plugin;

    $writepath=$base_plugin.'data/temp_dnsmasq';
    $fp=fopen($writepath,"w");

    fwrite($fp, "dhcp-range=wlan0,".$post_data['dhcp_start_wlan0'].",".$post_data['dhcp_end_wlan0'].",".$post_data['dhcp_expire_wlan0']."h\n");
    fwrite($fp, "dhcp-option=6,".$post_data['DNS1'].",".$post_data['DNS2']."\n");
    fwrite($fp, "dhcp-leasefile=/var/tmp/dnsmasq.leases");
    fclose($fp);
	exec("sudo cp ".$base_plugin."/data/temp_dnsmasq  /etc/dnsmasq.more.conf", $ret );
}
?>
