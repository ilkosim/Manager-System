<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Authors: Ilko Simeonov  
 *           Daniel Larraz <d.larraz [at] libelium [dot] com>
 */

include_once $base_plugin."php/display_security_info.php";
include_once $API_core.'parser_dhcp_server.php';
include_once $API_core.'parser_hostapd.php';

function make_wireless($path, $interface,$initial=true)
{
    global $url_plugin;
    global $section;
    global $plugin;
    global $base_plugin;

    $entries=parse_dhcp_server('wlan0');
	$hostap=parse_hostapd('/etc/hostapd/hostapd.wlan0.conf');
	$input=parse_interfaces($path);
//	print_r($hostap);
//	print_r($input);
//	echo $hostap['interface'];
//	echo $hostap['hw_mode'];
//	echo $hostap['wpa_passphrase'];
//	echo $input[$interface]['iface'];
//	echo $input[$interface]['address'];
//	echo $input[$interface]['up'][1];
   /* exec('echo "<br><b>Interfaz: </b> Wifi AP" > '.$base_plugin."data/simpleInfo");
    exec('echo "<b>Mode: </b> Manager" >> '.$base_plugin."data/simpleInfo");
    exec('echo "<b>IP: </b> '.$input[$interfaz]['address'].'" >> '.$base_plugin."data/simpleInfo");
    exec('echo "" >> '.$base_plugin."data/simpleInfo");*/

    $list='
    <form id="'.$interface.'" name="'.$interface.'">';
        $list.='
        <div class="title2">Wifi AP Network</div>
        <div id="network_plugin_content" class="plugin_content" style="position: relative;">
            <div id="subnet_alert" style="display: none;">Subnet must match</div>
            <table cellpadding="0" cellspacing="0" style="float: left;">
                <tbody>';
                    $list.='
                    <tr class="hidden">
                        <td>
                            IP method
                        </td>
                        <td>
                            <input type="text" name="iface_sel" id="iface_sel" value="static" readonly disabled style="background: #dedede; width: 122px;" />
                        </td>
                    </tr>
                    <tr>
                        <td>';
                            $list.="
                            <a id=address_lab>Address</a>
                        </td>
                        <td>
                            <input  onFocus=\"$('#subnet_alert').show();\" onBlur=\"$('#subnet_alert').fadeOut();\" type=\"text\" class=\"ms_mandatory ms_ip\" name=\"address\" id=\"address\"";
                            if ($input[$interface]['address']){
                                $list.=" value=".$input[$interface]['address'];
                            }
                            else
                            {
                                $list.=" value='10.10.10.1'";
                            }
                            $list.=" size=16 maxlength=15>
                        </td>
                        <td>
                            <div id=\"address_ms_cte\"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a id=netmask_lab>Netmask</a>
                        </td>
                        <td>
                            <input type=\"text\" class=\"ms_mandatory ms_ip\" name=\"netmask\" id=\"netmask\"";
                            if ($input[$interface]['netmask']){
                                $list.=" value=".$input[$interface]['netmask'];
                            }
                            else
                            {
                                $list.=" value='255.255.255.0'";
                            }
                            $list.=" size=16 maxlength=15>
                        </td>
                        <td>
                            <div id=\"netmask_ms_cte\"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a id=DNS1_lab>Primary DNS</a></td><td> <input type=\"text\" class=\"ms_mandatory ms_ip\" name=\"DNS1\" id=\"DNS1\"";
                            if ($input[$interface]['dns_primario']){
                                $list.=" value=".$input[$interface]['dns_primario'];
                            }
                            $list.=" size=16 maxlength=15>
                        </td>
                        <td>
                            <div id=\"DNS1_ms_cte\"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a id=DNS2_lab>Secondary DNS</a></td><td> <input type=\"text\" class=\"ms_mandatory ms_ip\" name=\"DNS2\" id=\"DNS2\"";
                            if ($input[$interface]['dns_secundario']){
                                $list.=" value=".$input[$interface]['dns_secundario'];
                            }
                            $list.=" size=16 maxlength=15>
                        </td>
                        <td>
                            <div id=\"DNS2_ms_cte\"></div>
                        </td>
                    </tr>";
                    $list.='
                </tbody>
            </table>
            <table cellpadding="0" cellspacing="0" style="float: left; margin-left: 100px;">
                <tbody>';
                    $list.='
                    <tr>
                        <td>';
                            $list.="
                            <label for=\"dhcp_start_$interface\">DHCP start ip address</label>
                        </td>
                        <td>
                            <input type=\"text\" class=\"ms_mandatory ms_ip\" name=\"dhcp_start_$interface\" id=\"dhcp_start_$interface\" ";
                                $list.=" value=\"".$entries['start'];
                            $list.="\" />";
                            $list.='
                        </td>
                    </tr>
                    <tr><td>
                            <div id="dhcp_start_'.$interface.'_ms_cte"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>';
                            $list.="
                            <label for=\"dhcp_end_$interface\">DHCP end ip address</label>";
                            $list.='
                        </td>
                        <td>';
                            $list.="
                            <input type=\"text\" class=\"ms_mandatory ms_ip\" name=\"dhcp_end_$interface\" id=\"dhcp_end_$interface\" ";
                                $list.=" value=\"".$entries['end'];
                            $list.="\" />";
                            $list.='
                        </td>
                    </tr>
                    <tr><td>
                            <div id="dhcp_end_'.$interface.'_ms_cte"></div>
                        </td>
                    </tr>
                    <tr>
                        <td>';
                            $list.="
                            <label for=\"dhcp_expire_$interface\">DHCP expire time</label>";
                            $list.='
                        </td>
                        <td>';
                            $list.="
                            <input type=\"text\" class=\"ms_numerical\" name=\"dhcp_expire_$interface\" id=\"dhcp_expire_$interface\" ";
                                $list.=" value=\"".$entries['expiration'];
                            $list.="\" />hours";
                            $list.='
                        </td>
                    </tr>
                    <tr><td>
                            <div id="dhcp_expire_'.$interface.'_ms_cte"></div>';
                            $list.='
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>';

    // Second block of options.
    $list.='
            <div class="title2">Radio</div>
            <div id="radio_plugin_content" class="plugin_content">
            <table cellpadding="0" cellspacing="0"><tbody>
            <tr><td>';
    $list.="ESSID</td><td><input type=\"text\" class=\"ms_mandatory\" name=\"essid\" id=\"essid\" size=16";
    if ($hostap['ssid'])
    {
    	$list.=" value=".$hostap['ssid'];
    }
    $list.="></td><td>Hide? ";
    $list.="<input name=\"hide\" id=\"hide\" type=\"checkbox\"";
    if ($hostap['ignore_broadcast_ssid']=='1')
    {
    	$list.=" checked";
    }
    $list.=">";
    $list.="</td><td><div id=\"essid_ms_cte\"></div></td></tr>";

//========================================================================	
	$list.="<tr><td>";
    $list.="Country Code</td><td> <input type=\"text\" class=\"ms_alnum\" name=\"country\" id=\"country\"";
    if ($hostap['country_code']){
            $list.=" value=".$hostap['country_code'];
    }
	$list.=" size=8 maxlength=2></td><td>According to ISO 3166-1/alpha-2</td><td><div class=\"nl\" id=\"frag_ms_cte\"></div></td></tr>";
//==========================================================================	
	
    $list.="<tr><td>";
    $list.="Frequency</td><td><div style=\"display:inline;\"> <select onchange=\"check_conditions();\" name=\"freq\" id=\"freq\" >";
    if (isset($hostap['channel'])&&($hostap['channel']==0)||($hostap['channel']>14))
    {
    	$list.="<option value=\"2\">2.4GHz</option>";
    	$list.="<option selected='yes' value=\"5\">5GHz</option>";
    }
    else
    {
    	$list.="<option selected='yes' value=\"2\">2.4GHz</option>";
    	$list.="<option value=\"5\">5GHz</option>";
    }
    $list.="</select></div>";

    $list.="</td></tr><tr><td>";
    $list.="Channel</td><td> <select onchange=\"check_conditions();\" name=\"channel2\" id=\"channel2\">";
    for($vuelta=1;$vuelta<=11;$vuelta++)
    {
    	$list.="<option ";
    	if ($hostap['channel']==$vuelta)
    	{ $list.=" selected='yes' ";}
    	$list.="value=".$vuelta.">".$vuelta."</option>";
    }
    $list.="</select>";
    $list.="<select onchange=\"check_conditions();\" name=\"channel5\" id=\"channel5\" >";
    $vuelta=0;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">auto</option>";
    for($vuelta=36;$vuelta<=64;$vuelta+=4)
    {
    	$list.="<option ";
    	if ($hostap['channel']==$vuelta)
    	{ $list.=" selected='yes' ";}
    	$list.="value=".$vuelta.">".$vuelta."</option>";
    }
	for($vuelta=100;$vuelta<=140;$vuelta+=4)
    {
    	$list.="<option ";
    	if ($hostap['channel']==$vuelta)
    	{ $list.=" selected='yes' ";}
    	$list.="value=".$vuelta.">".$vuelta."</option>";
    }
    $vuelta=149;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">".$vuelta."</option>";
    $vuelta=153;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">".$vuelta."</option>";
	$vuelta=157;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">".$vuelta."</option>";
	$vuelta=161;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">".$vuelta."</option>";
	$vuelta=165;
    $list.="<option ";
    if ($hostap['channel']==$vuelta)
    { $list.=" selected='yes' ";}
    $list.="value=".$vuelta.">".$vuelta."</option>";
    $list.="</select></td></tr>";

    $list.="<tr><td><div id=iwpriv_mode>";
    $list.="Protocol</div></td>";
    // Two selections b/g for 2.4 and a for 5GHz
    $list.="<td><div id=bg_dat> <select onchange=\"check_conditions();\" name=\"mode-abg\" id=\"mode-abg\">";
    if (($hostap['hw_mode']=='a')&&($hostap['ieee80211ac']=='1'))
    {
    	$list.="<option selected=\"yes\" value=3>802.11ac</option>";
    	$list.="<option value=1>802.11b</option>";
    	$list.="<option value=2>802.11g</option>";
		$list.="<option value=4>802.11n</option>";
    }
    elseif ($hostap['hw_mode']=='b')
    {
    	$list.="<option value=3>802.11ac</option>";
    	$list.="<option selected=\"yes\" value=1>802.11b</option>";
    	$list.="<option value=2>802.11g</option>";
		$list.="<option value=4>802.11n</option>";
    }
    elseif ($hostap['hw_mode']=='g')
    {
    	$list.="<option value=3>802.11ac</option>";
    	$list.="<option value=1>802.11b</option>";
    	$list.="<option selected=\"yes\" value=2>802.11g</option>";
		$list.="<option value=4>802.11n</option>";
    }
	elseif ($hostap['ieee80211n']=='1')
    {
    	$list.="<option value=3>802.11ac</option>";
    	$list.="<option value=1>802.11b</option>";
		$list.="<option value=2>802.11g</option>";
    	$list.="<option selected=\"yes\" value=4>802.11n</option>";
    }
    $list.="</select>";
	$list.='</tbody></table></div>';

        // Third block of options.

        $list.='
        <div id="security_div">';
            $list .= make_security ($interface);
            $list.='
        </div>';
    

        $list.='
        <div class="right_align">
            <input type="button" class="bsave" onclick="complex_ajax_call(\''.$interface.'\',\'output\',\''.$section.'\',\''.$plugin.'\',\'default\')" value="save">
        </div>
        <div id="output"></div>';
	
	return $list;
}
/*
function make_selector_arg($options)
{
    global $plugin;
    global $section;
    $list='
        <div class="title">WIFI</div>
        <div class="title2">Interface configuration</div>
            <div class="plugin_content">
                <label class="btext">Select interface </label>';
                $list.= make_select('interface_selector',$options,' ');
                $list.='
                <input type="hidden" id="plugin" value="'.$plugin.'" />
                <input type="hidden" id="section" value="'.$section.'" />
            </div>
        <div id="interface_info"></div>';
    return $list;

}*/
?>