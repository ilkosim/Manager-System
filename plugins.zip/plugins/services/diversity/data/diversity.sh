/usr/bin/cambia_diversidad.sh 0 0 0 0
/usr/bin/cambia_diversidad.sh 1 0 2 2
