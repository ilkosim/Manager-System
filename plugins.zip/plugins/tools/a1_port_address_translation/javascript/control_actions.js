//<![CDATA[

$(document).ready(function(){
  check_me();
});
function check_me()
{
    clear_test_alerts();
    // Hide configuration values if static.
    if ($('#iface_sel').val()=="static")
    {
        $('#address').show();        
        $('#netmask').show();        
        $('#gateway').show();
		$('#port').show();
		$('#port_def').hide();
		
        $('#address_ms_cte').show();
        $('#netmask_ms_cte').show();
        $('#gateway_ms_cte').show();

        $('#address').addClass('ms_mandatory ms_alnum');
        $('#netmask').addClass('ms_mandatory ms_numerical');
        $('#gateway').addClass('ms_mandatory ms_ip');
		$('#port').addClass('ms_mandatory ms_numerical');

        $('#address_lab').show();
        $('#netmask_lab').show();
        $('#gateway_lab').show();
        $('#port_lab').show();
        $('#port_def_lab').hide();
		
    }
    else
    {
        $('#address').hide();
        $('#netmask').hide();
        $('#gateway').hide();
		$('#port').hide();
		$('#port_def').show();

        $('#address_ms_cte').hide();
        $('#netmask_ms_cte').hide();
        $('#gateway_ms_cte').hide();

        $('#address').removeClass('ms_mandatory ms_alnum');
        $('#netmask').removeClass('ms_mandatory ms_numerical');
        $('#gateway').removeClass('ms_mandatory ms_ip');
		
        $('#address_lab').hide();
        $('#netmask_lab').hide();
        $('#gateway_lab').hide();
        $('#port_lab').hide();
        $('#port_def_lab').show();
		
    }
}
//]]>