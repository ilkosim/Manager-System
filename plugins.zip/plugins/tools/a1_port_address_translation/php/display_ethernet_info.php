<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */
//include_once $base_plugin.'php/convert_to_table.php';
 
 function make_eth()
{
    global $url_plugin;
    global $section;
    global $plugin;
	global $base_plugin;
	
    $list='<div class="title">PORT ADDRESS TRANSLATION</div>';
//--------------------------------------------------------------------------
		exec ('sudo iptables -v -L -t nat', $iptables);
        $list.='<div class="title2">IP Tables</div>
        <div id="plugin_content"><pre>'.implode('<br/>', $iptables).'</pre>';
		$list.='</div>';
//--------------------------------------------------------------------------

	$list.='<div class="title2">Add/Delete Port Address Translation</div>
			<div id="plugin_content">';
    $list.='<form id="eth" name="eth">
                <table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';
//
              $list.='
                    <tr class="hidden">
                        <td>
                            IP method
                        </td>
                        <td>
                            <input type="text" name="iface_sel" id="iface_sel" value="static"/>
                        </td>
                    </tr>';

	$list.="<tr><td>";
	$list.='<span class="nl" id=address_lab>Protocol</span></td><td> <select name="address" id="address">';
    	$list.="<option selected=\"yes\" value=tcp>TCP</option>";
    	$list.="<option value=udp>UDP</option>";
    	$list.="</select></td>";	
//---------------------------------------------------------------------------------------------
	$list.="<td>";
	$list.='<span class="nl" id=interface_lab>Outside Interface</span></td><td> <select name="interface" id="interface">';
    	$list.="<option selected=\"yes\" value=eth0>Eth0</option>";
    	$list.="<option value=lte0>lte0</option>";
    	$list.="</select></td>";	
//---------------------------------------------------------------------------------------------
    $list.='<td><div id="address_ms_cte"></div></td><td>';
    $list.='<span class="nl" id=netmask_lab>Outside Port</span></td><td> <input type="text" class="ms_mandatory ms_numerical" name="netmask" id="netmask"';
    $list.=' size="6" maxlength="12"></td></tr>';
//---------------------------------------------------------------------------------------------
    $list.="<tr><td>";
    $list.='<span class="nl" id=gateway_lab>To Inside Address</span></td><td> <input type="text" class="ms_mandatory ms_ip" name="gateway" id="gateway"';
    $list.=' size="12" maxlength="15"></td>';
//---------------------------------------------------------------------------------------------
    $list.='<td><span class="nl" id=port_lab>To Inside Port</span></td><td> <input type="text" class="ms_mandatory ms_numerical" name="port" id="port"';
	$list.=' size="6" maxlength="12"></td></tr>';
    $list.='</tbody></table></form>';
    $list.='
            <div class="right_align">
                <input class="bsave" type="button" onclick="complex_ajax_call(\'eth\',\'output\',\''.$section.'\',\''.$plugin.'\',\'add\')" value="add"></fieldset>
                <input class="bsave" type="button" onclick="complex_ajax_call(\'eth\',\'output\',\''.$section.'\',\''.$plugin.'\',\'delete\')" value="delete"></fieldset>
            </div>
        </div>';
	return $list;
}

?>