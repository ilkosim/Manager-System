#!/bin/bash
#apaga.sh

#Exportamos el PIN deseado
echo 7 > /sys/class/gpio/export

#Establecemos la direccion (salida o entrada)
echo out > /sys/class/gpio/gpio7/direction

#Activamos la salida del rele dandole un valor de 1 al bit
echo 1 > /sys/class/gpio/gpio7/value
