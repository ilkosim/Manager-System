<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */

function addInputGprs()
{
    global $section;
    global $plugin;
    global $url_plugin;
    global $base_plugin;

	exec ('sudo mount -t debugfs none /sys/kernel/debug');
	exec ('sudo cat /sys/kernel/debug/gpio', $gpio_state);
	$list.='<div class="title">GPIO</div>';
	$list.='<div class="title2">GPIO State</div>
		    <div id="plugin_content">';
	$list.='<div class="information">		
	       '.implode('</br>',$gpio_state).'</div></div>';
//=======================================================================================================		   

	$list.='<div class="title2">Set GPIO</div>
            <div id="plugin_content">';

    $list.='<div class="information">';
	
	$list.='<form id="gprs" name="gprs"><table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody><tr>';
	$list.="<td colspan='3' rowspan='1'>";
//	$list.="<p class='advice'>Connectivity information from operators provided without warranty.</p>";

    $list.="<tr><td>";
	$list.='<span class="nl">GPIO Pin number</span></td><td> <input type="text" class="ms_mandatory" name="pin_number" id="pin_number"';
    $list.=' size="8" maxlength="2"></td></tr>';

    $list.="<tr><td></td><td class='ss'>";
    $list.='<span class="ref" onclick="allow_edit();">Click here</span> to edit';
    $list.="</td></tr>";
	$list.='<tr><td><span class="nl">Direction</span></td><td><select name="dial" id="dial" onchange="onchange_protocol()" class="readonly" readonly />';
	    $list.="<option value=empty>None</option>";
    	$list.="<option value=out>Out</option>";
		$list.="<option value=in>In</option>";
    $list.="</select></td>";
	
    $list.="<td>Out direction</td><td> <select name='username' id='username' class='readonly' readonly />";
	    $list.="<option selected=\"yes\" value=emp>None</option>";
    	$list.="<option value=1>1</option>";
		$list.="<option value=0>0</option>";
    $list.="</select></td><td id=adv name=adv class='advice'>High (1) or Low (0)";
    $list.="</td><td>"; 

	$list.='
            <div class="right_align">
				<input type="button" class="bsave" onclick="complex_ajax_call(\'gprs\',\'output\',\''.$section.'\',\''.$plugin.'\',\'save\')" value="save">
				<input type="button" class="bsave" onclick="complex_ajax_call(\'gprs\',\'output\',\''.$section.'\',\''.$plugin.'\',\'save_restart\')" value="reset">
	        </div>';
	
	$list.="</td></tr>";
	$list.="</tbody></table></form>";
	$list.='</div></div>';
	return $list;
}

?>