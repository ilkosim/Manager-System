<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */

// Predefined variables:
// $section contains the section folder name.
// echo "section=".$section."<br>";
// $plugin contains the plugin folder name.
// echo "plugin=".$plugin."<br>";
// $section and $plugin can be used to make a link to this plugin by just reference
// echo "<a href=\"index.php?section=$section&plugin=$plugin\">This plugin</a>"."<br>";
// $base_plugin contains the path that must be used as start to includes for
// plugin includes that need the local path.
// example: include_once $base_plugin.'php/my_include.php';
// echo "base_plugin=".$base_plugin."<br>";
// $url_plugin contains the url base that must be used to include html items
// such as images.
// example: <img src="'.url_plugin.'images/my_image.png">
// echo "url_plugin=".$url_plugin."<br>";
// $API_core contains the path to the core API folder.
// example: include_once $API_core.'is_active.php';
// echo "API_core=".$API_core."<br>";

// Plugin server produced data will returned to the ajax call that made the
// request.
include_once $API_core.'complex_ajax_return_functions.php';
include_once $API_core.'json_api.php';
include_once $API_core.'form_fields_check.php';

if ($_POST['type']=="save_restart")
{
    $post_data=jsondecode($_POST['form_fields']);
//	file_put_contents("/home/AVL/post_data.txt", $post_data);
    $fields_check_types = Array (
        'city'  => Array ('ms_text' ,'ms_mandatory'),
        'intersection'  => Array ('ms_numerical','ms_mandatory'),
		'maxquerytime'  => Array ('ms_numerical','ms_mandatory'),
		'waitafterquery'  => Array ('ms_numerical','ms_mandatory'),
		'timedelaytolerance'  => Array ('ms_numerical','ms_mandatory'),
		'timedelaymaxallowed'  => Array ('ms_numerical','ms_mandatory'),
		'chartexpiresfrom'  => Array ('ms_numerical','ms_mandatory'),
		'chartexpiryperiod'  => Array ('ms_numerical','ms_mandatory'),
        'serverip'  => Array ('ms_ip','ms_mandatory'),
        'serverport'  => Array ('ms_numerical','ms_mandatory'),
		'modembaudrate'  => Array ('ms_numerical','ms_mandatory'),
		'controllerbaudrate'  => Array ('ms_numerical','ms_mandatory'),
        );
    if(are_form_fields_valid ($post_data, $fields_check_types))
	{
		save_avl($post_data);
        response_additem("script", 'alert("Data saved")');
    }
    response_return();
}	
function save_avl($post_data)
{
	global $base_plugin;

    $writepath=$base_plugin.'data/temp_avl';
    $fp=fopen($writepath,"w");

	fwrite($fp,"[Main Settings]\n");
    fwrite($fp,"City=".$post_data['city']."\n");
    fwrite($fp,"INTERSECTION=".$post_data['intersection']."\n");
    fwrite($fp,"MAXQUERYTIME=".$post_data['maxquerytime']."\n");
    fwrite($fp,"WAITAFTERQUERY=".$post_data['waitafterquery']."\n");
    fwrite($fp,"TIMEDELAYTOLERANCE=".$post_data['timedelaytolerance']."\n");
    fwrite($fp,"TIMEDELAYMAXALLOWED=".$post_data['timedelaymaxallowed']."\n");
    fwrite($fp,"SYNCTIME=".$post_data['synctime']."\n");
	fwrite($fp,"SYNCDBATSTART=".$post_data['syncdbatstart']."\n");
	fwrite($fp,"[Serial Communication Settings]\n");
	fwrite($fp,"[/dev/ttyUSB0]\n");
	fwrite($fp,"MODEMDEVICE=".$post_data['modemdevice']."\n");
    fwrite($fp,"MODEMBAUDRATE=".$post_data['modembaudrate']."\n");
	fwrite($fp,"[/dev/ttyUSB1]\n");
	fwrite($fp,"CONTROLLERDEVICE=".$post_data['controllerdevice']."\n");
    fwrite($fp,"CONTROLLERBAUDRATE=".$post_data['controllerbaudrate']."\n");
	fwrite($fp,"[Database Settings]\n");
    fwrite($fp,"DATABASEPATH=".$post_data['databasepath']."\n");
	fwrite($fp,"[Chart data expires from a time moment in the past, related to current local time.]\n");
	fwrite($fp,"[It is specified here as parameter CHARTEXPIRESFROM, dimension is minutes, range: 0-23*60]\n");
    fwrite($fp,"CHARTEXPIRESFROM=".$post_data['chartexpiresfrom']."\n");
	fwrite($fp,"[Chart data is considered as expired when its <ETA> is within CHARTEXPIRYPERIOD in the past,]\n");
	fwrite($fp,"[according to the moment calculated as (current local time - CHARTEXPIRESFROM), dimension is minutes, range: 0-23*60]\n");
    fwrite($fp,"CHARTEXPIRYPERIOD=".$post_data['chartexpiryperiod']."\n");
	fwrite($fp,"[AVL Communication Settings]\n");
    fwrite($fp,"PDURL=".$post_data['serverip']."\n");
	fwrite($fp,"PDPORT=".$post_data['serverport']."\n");
	fwrite($fp,"[Logs]\n");
    fwrite($fp,"LOGPATH=".$post_data['logpath']."\n");

    fclose($fp);
	exec('sudo cp '.$base_plugin."data/temp_avl /home/dev/LocalPriority/conf.ini");
}

?>