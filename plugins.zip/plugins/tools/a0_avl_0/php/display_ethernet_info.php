<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */
include_once $base_plugin.'data/parser_ini.php';
function make_avl()
{
    global $url_plugin;
    global $section;
    global $plugin;
	$avl=Array();
	$avl=parse_ini('/home/dev/LocalPriority/conf.ini');
//	file_put_contents("/home/AVL/avlarray.txt", $avl);
//	print_r($avl);
    $list='<div class="title">Public Transport Priority</div>';
	
	$list.='<div class="title2">Main Settings</div>
			<form id="avl" name="avl">
			<div id="plugin_content">
			<table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';

//=======================================================
    $list.="<tr><td>";
	$list.='<span class="nl" id=city_lab>City</span></td><td> <input type="text" class="ms_text" name="city" id="city"';
    if ($avl['City']){
        $list.=" value=".$avl['City'];
    }
    $list.=' size="16" maxlength="15"></td>';	
//======================================================
    $list.="<td>";
	$list.='<span class="nl" id=intersection_lab>Intersection</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="intersection" id="intersection"';
    if ($avl['INTERSECTION']){
        $list.=" value=".$avl['INTERSECTION'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//======================================================
    $list.="<tr><td>";
	$list.='<span class="nl" id=maxquerytime_lab>Max query time</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="maxquerytime" id="maxquerytime"';
    if ($avl['MAXQUERYTIME']){
        $list.=" value=".$avl['MAXQUERYTIME'];
    }
    $list.=' size="16" maxlength="15"></td>';
//=====================================================
    $list.="<td>";
	$list.='<span class="nl" id=waitafterquery_lab>Wait after query</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="waitafterquery" id="waitafterquery"';
    if ($avl['WAITAFTERQUERY']){
        $list.=" value=".$avl['WAITAFTERQUERY'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
    $list.="<tr><td>";
	$list.='<span class="nl" id=timedelaytolerance_lab>Time delay tolerance</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="timedelaytolerance" id="timedelaytolerance"';
    if ($avl['TIMEDELAYTOLERANCE']){
        $list.=" value=".$avl['TIMEDELAYTOLERANCE'];
    }
    $list.=' size="16" maxlength="15"></td>';
//=====================================================
    $list.="<td>";
	$list.='<span class="nl" id=timedelaymaxallowed_lab>Time delay max allowed</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="timedelaymaxallowed" id="timedelaymaxallowed"';
    if ($avl['TIMEDELAYMAXALLOWED']){
        $list.=" value=".$avl['TIMEDELAYMAXALLOWED'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	$list.='<tr><td>';
	$list.='<span class="nl" id=synctime_lab>Sync time</span></td><td><select id="synctime" name="synctime">';

	if($avl['SYNCTIME']=='false')
	{
		$list.='<option value="false" selected="false">false</option>
				<option value="true">true</option>
				';
	}
	else
	{
		$list.='<option value="false">false</option>
				<option value="true" selected="true">true</option>
				';
	}

	$list.='</td>';

//=====================================================
	$list.='<td>';
	$list.='<span class="nl" id=syncdbatstart_lab>Sync db at start</span></td><td><select id="syncdbatstart" name="syncdbatstart">';

	if($avl['SYNCDBATSTART']=='false')
	{
		$list.='<option value="false" selected="false">false</option>
				<option value="true">true</option>
				';
	}
	else
	{
		$list.='<option value="false">false</option>
				<option value="true" selected="true">true</option>
				';
	}

	$list.='</td></tr></tbody></table></div>';

//=====================================================
	$list.='<div class="title2">Communication Settings</div>
			<div id="plugin_content">
			<table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';
//=====================================================
	$list.="<tr><td>";
    $list.='<span class="nl" id=server_ip_lab>Server IP</span></td><td> <input type="text" class="ms_ip ms_mandatory" name="serverip" id="serverip"';
    if ($avl['PDURL']){
        $list.=" value=".$avl['PDURL'];
    }
    $list.=' size="16" maxlength="15"></td>';
//=====================================================
    $list.="<td>";
	$list.='<span class="nl" id=server_port_lab>Server port</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="serverport" id="serverport"';
    if ($avl['PDPORT']){
        $list.=" value=".$avl['PDPORT'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	$list.="<tr><td>";
	$list.='<span class="nl" id=modemdevice_lab>Modem device</span></td><td> <input type="text" name="modemdevice" id="modemdevice"';
    if ($avl['MODEMDEVICE']){
        $list.=" value=".$avl['MODEMDEVICE'];
    }
    $list.=' size="16" maxlength="15"></td>';
//=====================================================
	$list.="<td>";
	$list.='<span class="nl" id=modembaudrate_lab>Modem baud rate</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="modembaudrate" id="modembaudrate"';
    if ($avl['MODEMBAUDRATE']){
        $list.=" value=".$avl['MODEMBAUDRATE'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	$list.="<tr><td>";
	$list.='<span class="nl" id=controllerdevice_lab>Controller device   </span></td><td> <input type="text" name="controllerdevice" id="controllerdevice"';
    if ($avl['CONTROLLERDEVICE']){
        $list.=" value=".$avl['CONTROLLERDEVICE'];
    }
    $list.=' size="16" maxlength="15"></td>';
//=====================================================
	$list.="<td>";
	$list.='<span class="nl" id=controllerbaudrate_lab>Controller baud rate</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="controllerbaudrate" id="controllerbaudrate"';
    if ($avl['CONTROLLERBAUDRATE']){
        $list.=" value=".$avl['CONTROLLERBAUDRATE'];
    }
    $list.=' size="16" maxlength="15">';
//=====================================================
	$list.='</td></tr></tbody></table></div>';

	$list.='<div class="title2">Chart Data Settings</div>
			<div id="plugin_content">
			<table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';	
	
//=====================================================
	$list.="<tr><td>";
	$list.='<span class="nl" id=chartexpiresfrom_lab>Chart expires from</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="chartexpiresfrom" id="chartexpiresfrom"';
    if ($avl['CHARTEXPIRESFROM']){
        $list.=" value=".$avl['CHARTEXPIRESFROM'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	$list.="<tr><td>";
	$list.='<span class="nl" id=chartexpiryperiod_lab>Chart expiry period</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="chartexpiryperiod" id="chartexpiryperiod"';
    if ($avl['CHARTEXPIRYPERIOD']){
        $list.=" value=".$avl['CHARTEXPIRYPERIOD'];
    }
    $list.=' size="16" maxlength="15">';
//=====================================================
	$list.='</td></tr></tbody></table></div>';

	$list.='<div class="title2">File Path</div>
			<div id="plugin_content">
			<table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';

//=====================================================

    $list.="<tr><td>";
	$list.='<span class="nl" id=databasepath_lab>Database</span></td><td> <input type="text" name="databasepath" id="databasepath"';
    if ($avl['DATABASEPATH']){
            $list.=" value=".$avl['DATABASEPATH'];
    }
	$list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
    $list.="<tr><td>";
    $list.='<span class="nl" id=logpath_lab>Log file</span></td><td> <input type="text" name="logpath" id="logpath"';
    if ($avl['LOGPATH']){
        $list.=" value=".$avl['LOGPATH'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	
	$list.='<tr><td>
            </tbody></table></div></form>';		
    $list.='
            <div class="right_align">
                <input class="bsave" type="button" onclick="complex_ajax_call(\'avl\',\'output\',\''.$section.'\',\''.$plugin.'\',\'save_restart\')" value="save & Apply"></fieldset>
            </div>';

	return $list;
}

?>