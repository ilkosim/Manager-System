<?php
function convert_to_table($data,$id,$th='')
{
    // Given an array it will convert the array to a table using each component as row
    // and space or tabs as column separator.
    $pattern_text = '/[\t]+/';
    $return='<table id="'.$id.'"><tbody>';
    if(!empty($th)){
        $return.='<tr>'.$th.'</th>';
    }
    if(!empty($data)){
        foreach ($data as $line)
        {
            // Remove \n an not desired separators.
            $line=trim($line);
            $return.='<tr><td>'.preg_replace($pattern_text,'</td><td>',$line).'</td></tr>';
        }
    }
    $return.='</tbody></table>';
    return $return;
}
?>