<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */
include_once $base_plugin.'php/convert_to_table.php';
 
 function make_eth($input,$path,$interfaz)
{
    global $url_plugin;
    global $section;
    global $plugin;
	global $base_plugin;
	
	$input=parse_interfaces($path);
	if ($interfaz=='eth0')
	{
        $list='<div class="title">ROUTE</div>';
	}
//--------------------------------------------------------------------------
        $list.='<div class="title2">IP Route</div>
                <div id="plugin_content">';

        $list.='<div class="information">';

        exec('route -n',$netstat);
        //echo "<pre>".print_r($netstat,true)."</pre>";
        $primero = true;
        $i=0;
        foreach ($netstat as $line)
        {
            if($i<2){
                // This is table headers, and should be modified in a different way                
                $i++;
            } else{
                $pattern = "{[ \t]+}";
                $replace = "\t";
                $line = preg_replace($pattern,$replace, $line);
                $data[]=$line;
            }
        }
        $th='<th>Destination</th><th>Gateway</th><th>Genmask</th><th>Flags</th><th>Metric</th><th>Ref</th><th>Use</th><th>Iface</th>';
        $list.= convert_to_table($data,'netstat',$th);
        $list.='</div></div>';

//--------------------------------------------------------------------------
	$list.='<div class="title2">Add/Delete Route</div>
			<div id="plugin_content">';
    $list.='<form id="eth" name="eth">
                <table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';

    $list.='<tr><td>IP method</td><td> <select name="iface_sel" id="iface_sel" onchange="check_me()" >';
    if ($input[$interfaz]['iface']=='static')
    	{
    	$list.="<option selected=\"yes\" value=static>Static</option>";
    	$list.="<option value=dhcp>Default GW</option>";
    	$list.="</select></td>";
    	}
    else
    	{
    	$list.="<option value=static>Static</option>";
    	$list.="<option selected=\"yes\" value=dhcp>Default GW</option>";
    	$list.="</select></td>";
    	}
    $list.='<td><span class="nl" id=port_def_lab>Port</span></td><td> <select name="port_def" id="port_def">';
    	$list.="<option selected=\"yes\" value=eth0>Eth0</option>";
    	$list.="<option value=lte0>Lte0</option>";
    	$list.="</select></td>";
		$list.="</tr>";
//------------------------------------------------------------------------------------------------
    $list.="<tr><td>";
	$list.='<span class="nl" id=address_lab>Network</span></td><td> <input type="text" class="ms_mandatory ms_ip" name="address" id="address"';
	$list.=' size="12" maxlength="15"></td>';
//---------------------------------------------------------------------------------------------
    $list.='<td><div id="address_ms_cte"></div></td>
            <td>';
    $list.='<span class="nl" id=netmask_lab>Netmask</span></td><td> <input type="text" class="ms_mandatory ms_ip" name="netmask" id="netmask"';
    $list.=' size="12" maxlength="15"></td>';
//---------------------------------------------------------------------------------------------
    $list.='<td><div id="netmask_ms_cte"></div></td>
			<td>';
    $list.='<span class="nl" id=gateway_lab>Gateway</span></td><td> <input type="text" class="ms_mandatory ms_ip" name="gateway" id="gateway"';
    $list.=' size="12" maxlength="15"></td>';
    $list.='<td><div id="gateway_ms_cte"></div></td>';
//---------------------------------------------------------------------------------------------
    $list.='<td><span class="nl" id=port_lab>Port</span></td><td> <select name="port" id="port">';
    	$list.="<option selected=\"yes\" value=eth0>Eth0</option>";
    	$list.="<option value=lte0>Lte0</option>";
    	$list.="</select></td></tr>";
    $list.='</tbody></table></form>';
    $list.='
            <div class="right_align">
                <input class="bsave" type="button" onclick="complex_ajax_call(\'eth\',\'output\',\''.$section.'\',\''.$plugin.'\',\'add\')" value="add"></fieldset>
                <input class="bsave" type="button" onclick="complex_ajax_call(\'eth\',\'output\',\''.$section.'\',\''.$plugin.'\',\'delete\')" value="delete"></fieldset>
            </div>
        </div>';
	return $list;
}

?>