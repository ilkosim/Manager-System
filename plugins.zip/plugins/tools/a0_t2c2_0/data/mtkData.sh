#!/bin/bash
#T2C2 server of Traffic Light Controllers for 3G network in Plovdiv: "172.22.41.2"
#T2C2 server of Traffic Light Controllers for FO network in Plovdiv: "172.16.20.3"
#T2C2 server of Traffic Light Controllers for 3G network in Sofia:   "172.22.39.4"
HOST="172.22.41.2"
PORT="10101"
RS232DEV="/dev/ttyUSBBOARD5"
SERIALSETTINGS="nonblock,b9600,echo=0,icanon=0,rawer,ignbrk=1,cs8,parenb=0"
APP="socat"


echo -e "${PROCANDARGS}"

PROCANDARGS="$APP file:$RS232DEV,$SERIALSETTINGS TCP:$HOST:$PORT "

$PROCANDARGS &

while true; do
  # call the script that has monitoring function every 5 seconds
  # because once <socat> receives TCP socket error, it exits and we could not guarantee RS232 data redirection
  sleep 5;
  ./pgrepMTK;
done
