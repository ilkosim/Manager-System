<?php
/*
 *  
 *  
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  Version 0.1
 *  Author: Ilko Simeonov
 */
include_once $base_plugin.'data/parser_t2c2.php';
function make_t2c2()
{
    global $url_plugin;
    global $section;
    global $plugin;
	$avl=Array();
	$avl=parse_ini('/home/dev/mtkData.sh');
//	file_put_contents("/home/AVL/avlarray.txt", $avl);
//	print_r($avl);
    $list='<div class="title">Traffic Control</div>';
	
//=====================================================
	$list.='<div class="title2">Communication Settings</div>
			<div id="plugin_content">
			<form id="avl" name="avl">
			
			<table style="text-align: left;" border="0" cellpadding="2" cellspacing="2"><tbody>';
//=====================================================
	$list.="<tr><td>";
    $list.='<span class="nl" id=server_ip_lab>Server IP</span></td><td> <input type="text" class="ms_ip ms_mandatory" name="serverip" id="serverip"';
    if ($avl['HOST']){
        $list.=" value=".$avl['HOST'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
    $list.="<tr><td>";
	$list.='<span class="nl" id=server_port_lab>Server port</span></td><td> <input type="text" class="ms_numerical ms_mandatory" name="serverport" id="serverport"';
    if ($avl['PORT']){
        $list.=" value=".$avl['PORT'];
    }
    $list.=' size="16" maxlength="15"></td></tr>';
//=====================================================
	$list.="<tr><td>";
	$list.='<span class="nl" id=modemdevice_lab>Local Modem</span></td><td> <input type="text" name="modemdevice" id="modemdevice"';
    if ($avl['RS232DEV']){
        $list.=" value=".$avl['RS232DEV'];
    }
    $list.=' size="16" maxlength="15"></td></tr></tbody></table></form>';
//=====================================================
    $list.='
            <div class="right_align">
                <input class="bsave" type="button" onclick="complex_ajax_call(\'avl\',\'output\',\''.$section.'\',\''.$plugin.'\',\'save_restart\')" value="save & Apply"></fieldset>
            </div>
		</div>';
	return $list;
}
?>