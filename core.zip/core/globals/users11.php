<?php

$authorized_users = Array(
    'root' => '$1$K/UmLYxB$C9z07kCqhHgAMORBnB43a1',
    'admin' => '$1$CpXOEPGG$w02fZWmotGNjEWS6wzTii.',
);

?>
