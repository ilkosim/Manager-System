<?php

$authorized_users = Array(
    'root' => '$1$hsP9n7K4$s3iE.gIlAKTmTykPH3Byt1',
);

?>
