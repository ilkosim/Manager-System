<?php
/*
 * 
 *
 * This file is part of Meshlium Manager System.
 * Meshlium Manager System will be released as free software; until then you cannot redistribute it
 * without express permission by libelium. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * 
 *
 * Version 0.1.0 
 *  Author: Ilko Simeonov
 */
function write_rule($join,$base)
{
	global $API_core;
	include_once $API_core.'net_conversions.php';
	
	$interfaces=parse_interfaces('/etc/network/interfaces.d/'.$join[($base)].'.conf'); //new line
	$network=network($interfaces[$join[$base]]['address'], $interfaces[$join[$base]]['netmask']); //new line
	$mask=mask2cidr($interfaces[$join[$base]]['netmask']); //new line
		exec('sudo iptables -t nat -A POSTROUTING -s '.$network."/".$mask.' -o '.$join[2].' -j MASQUERADE');
}
function save_join($join,$conf_file='',$rules_file='')
{
    global $base_plugin;

//	file_put_contents('/home/join.txt', $join);
	
    if ($conf_file=='')
    {
        $conf_file=$base_plugin.'data/join.conf';
    }
	
	$rules=file($conf_file);
//	file_put_contents('/home/rules.txt', $rules);
	$ru=$rules[0];
	similar_text($join, $ru, $percent);
//	file_put_contents('/home/percent.txt', $percent);
	if ((count($rules)>1)||($percent>85))
	{
		response_additem("script", 'alert("This rule already exists")');
	}
	else 
	{ 
		$fp=fopen($conf_file,"a");
		fwrite($fp,$join."\n");
		fclose($fp);
		unset($fp);
		$rules=file($conf_file);
		$join_array=explode('|',trim($join));
		write_rule($join_array,'0');
	}
}
function delete_join_rule($rule_number,$conf_file='',$rules_file='')
{

    global $base_plugin;

    if ($conf_file=='')
    {
        $conf_file=$base_plugin.'data/join.conf';
    }

    // Load old config file and unset rule number.
    $rules=file($conf_file);

	$drule=$rules[$rule_number];
	unset($rules[$rule_number]);
	$join_array=explode('|',trim($drule));
	write_deleted_rule($join_array,'0');

    // Rewrite the configuration file without rule number.
    $fp=fopen($conf_file,"w");
    foreach($rules as $rule)
    {
        fwrite($fp,$rule);
    }
	fclose($fp);
    unset($fp);
}
function write_deleted_rule($join,$base)
{
	global $API_core;
	include_once $API_core.'net_conversions.php';
	
	$interfaces=parse_interfaces('/etc/network/interfaces.d/'.$join[($base)].'.conf'); //new line
	$network=network($interfaces[$join[$base]]['address'], $interfaces[$join[$base]]['netmask']); //new line
	$mask=mask2cidr($interfaces[$join[$base]]['netmask']); //new line
		exec('sudo iptables -t nat -D POSTROUTING -s '.$network."/".$mask.' -o '.$join[2].' -j MASQUERADE');
}
?>
