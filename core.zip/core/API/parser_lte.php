<?php
/*
 * 
 *
 * This file is part of Meshlium Manager System.
 * Meshlium Manager System will be released as free software; until then you cannot redistribute it
 * without express permission by libelium. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * 
 *
 * Version 0.1.0 
 *  Author: Ilko Simeonov
 */
// This file just implements a parser for meshlium /etc/wvdial.conf files
function parse_lte ( $filepath ) 
{
	unset ($ini);	
	unset ($return);
	unset ($line);
	if (file_exists($filepath))
	{
		$ini = file($filepath);
	    // Check for an empty file
	    if ( count( $ini ) == 0 ) { return array(); }
		//Make an array with the values in /etc/hosts
	    $values = array();
	    $return = array();
	        
		// Start parser
		// for each line we are going to parse the file
	    foreach( $ini as $line ){
			// with trim just take out unwanted characters
	        $line = trim( $line );
	        // if first character is a # we know is a comment and pass through
			if ( $line == '' || $line{0} == '#' ) 
			{	
				if (substr($line,1,8)=='operator')
				 $return['operator']=substr($line,10);
				if (substr($line,1,7)=='country')
				 $return['country']=substr($line,9);
			 	continue;
			}
	        // We will have as many rows of data as lines with data in /etc/wvdial.conf
			if (substr($line,6)=='BUSY')
			{$return['BUSY']=substr($line,6);}
			if (substr($line,6)=='\'NO CARRIER\'')
			{$return['NO CARRIER']=substr($line,6);}
			if (substr($line,6)=='ERROR')
			{$return['ERROR']=substr($line,6);}
			if (substr($line,0,7)=='TIMEOUT')
			{$return['TIMEOUT']=substr($line,8,10);}
			if (substr($line,0,11)=='OK \'AT+CFUN')
			{
				$linea= explode( '=', $line,2);
				$linea=preg_replace('/\'/','',$linea);
				$return['CFUN']=$linea[1];
			}
			if (substr($line,0,11)=='OK \'AT+CPIN')
			{
				$linea= explode( '=', $line,2);
				$linea=preg_replace('/[^A-Za-z0-9\-]/','',$linea);
				$return['pin']=$linea[1];
			}
			if (substr($line,0,15)=='OK \'AT\^NDISDUP')
			{
				$linea=explode( ',', $line,3);
				$linea[2]= trim($linea[2], '""\'');
				$linea=preg_replace('/\"\'/','',$linea);
				$return['apn']=$linea[2];
			}
	    }	    
		return $return;
	}
    
}
?>