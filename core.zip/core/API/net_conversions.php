<?php
// Copyright (C) 2005  James Bly
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 
function ip2bin($ip)
{
    $ret = '';
    if(!preg_match("/^\d+\.\d+\.\d+\.\d+$/", $ip)) return -1;
    foreach(explode(".", $ip) as $a)
    {
      if(!is_numeric($a)) return -1;
      $ret .= str_pad(decbin($a), 8, 0, STR_PAD_LEFT);
    }
    return $ret;
}
 
function cidr($ip)
{
    if(preg_match("/^(\d+.\d+.\d+.\d+)\/(\d+)$/", $ip, $matches))
    {
      return array($matches[1], bin2ip(netmask($matches[2])));
    } else {
      return false;
    }
}
 
function bin2ip($bits)
{
    if(!preg_match("/^([0-9]{8})([0-9]{8})([0-9]{8})([0-9]{8})$/", $bits, $matches)) return -1;
    return sprintf("%s.%s.%s.%s", bindec($matches[1]), bindec($matches[2]), bindec($matches[3]), bindec($matches[4]));
}
 
function bitmask($mask)
{
    $bits = ip2bin($mask);
    if(preg_match("/^(1+)(0+)$/", $bits, $matches))
      return strlen($matches[1]);
    else
      return -1;
}
 
function netmask($bits)
{
    $ret = '';
    if(!preg_match("/^\d+$/", $bits)) return -1;
    for($i = 0; $i < 32; $i++)
      $ret .= ($bits > $i)?1:0;
    return $ret;
}
 
function network($ip, $mask)
{
    $ret = '';
    $bitip = ip2bin($ip);
    $bitmask = ip2bin($mask);
    for($i = 0; $i < 32; $i++)
    {
      if($bitmask{$i} == '1')
        $ret .= $bitip{$i};
      else
        $ret .= '0';
    }
    return bin2ip($ret);
}
 
function broadcast($ip, $mask)
{
    $ret = '';
    $bitip = ip2bin($ip);
    $bitmask = ip2bin($mask);
    for($i = 0; $i < 32; $i++)
    {
      if($bitmask{$i} == '1')
        $ret .= $bitip{$i};
      else
        $ret .= '1';
    }
    return bin2ip($ret);
}
 
function in_network($check, $network, $netmask)
{
    $c = '';
    $b = '';
    $cip = ip2bin($check);
    $nip = ip2bin(network($network, $netmask));
    $bip = ip2bin(broadcast($network, $netmask));
    $bitmask = ip2bin($netmask);
    for($i = 0; $i < 32; $i++)
    {
      if($bitmask{$i})
        if($cip{$i} != $nip{$i}) return false;
      else
      {
        $c .= $cip{$i};
        $b .= $bip{$i};
      }
    }
    if(bindec($c) > bindec($b)) return false;
    else return 1;
}

function mask2cidr($mask)
{
  $long = ip2long($mask);
  $base = ip2long('255.255.255.255');
  return 32-log(($long ^ $base)+1,2);

  /* xor-ing will give you the inverse mask,
      log base 2 of that +1 will return the number
      of bits that are off in the mask and subtracting
      from 32 gets you the cidr notation */
}
?>
