<?php
/*
 * 
 *
 * This file is part of Meshlium Manager System.
 * Meshlium Manager System will be released as free software; until then you cannot redistribute it
 * without express permission by libelium. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * 
 *
 * Version 0.1.0 
 *  Author: Ilko Simeonov
 */
function save_lte($post,$write_path='')
{
    global $base_plugin;

    if ($write_path=='')
    {
        $write_path=$base_plugin.'data/sunrise.HUAWEI';
    }
	
	$fp=fopen($write_path,"w");
	
    // first we must put our comment to know this is a known operator.
    if ($post['country_operators']!='other')
    {
        fwrite($fp,"#operator ".$post['country_operators']."\n");
    }
    if ($post['country_list']!='other')
    {
        fwrite($fp,"#country ".$post['country_list']."\n");
    }
    fwrite($fp,"ABORT BUSY\n");
    fwrite($fp,"ABORT 'NO CARRIER'\n");
	fwrite($fp,"ABORT ERROR\n");
    fwrite($fp,"TIMEOUT 10\n");
	fwrite($fp,"'' ATZ\n");
    fwrite($fp,"OK 'AT+CFUN=1'\n");
    //Here goes the options that contains the form values.
    if ($post['PIN'])
    {
    fwrite($fp,"OK 'AT+CPIN=.".$post['PIN'].".'\n");
    }
	fwrite($fp,"OK 'AT\^NDISDUP=1,1,\"".$post['init1']."\"'\n"); // NEW
	fwrite($fp,"OK\n");
    // Let's close the file descriptor.
    fclose($fp);
	// To avoid direct access of www-data to system files, we will indirect the access.
	// To do that we first write the new interfaces in a temp file and call with sudo a script that
	// will move the data to the correct place. Doing so will slow action but secure it a bit.
	// Now we call the script that will move $write_path to $read_path.
    
}

//if(file_exists($filename))
//if($_SERVER['QUERY_STRING'])
?>