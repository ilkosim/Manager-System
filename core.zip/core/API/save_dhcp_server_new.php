<?php
/*
 * 
 *
 * This file is part of Meshlium Manager System.
 * Meshlium Manager System will be released as free software; until then you cannot redistribute it
 * without express permission by libelium. 
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * 
 *
 * Version 0.1.0 
 *  Author: Ilko Simeonov
 */

function update_dhcp($dhcp_configuration)
{
    $new_dhcp_configuration=parse_dhcp_server();
    // Actualize eth0, wlan0 and wlan1 information.
    if ($dhcp_configuration['dhcp_server_eth0']=='on')
    {
        $new_dhcp_configuration['eth0']['start']=$dhcp_configuration['dhcp_start_eth0'];
        $new_dhcp_configuration['eth0']['end']=$dhcp_configuration['dhcp_end_eth0'];
        $new_dhcp_configuration['eth0']['expire']=$dhcp_configuration['dhcp_expire_eth0'];
    }
    else
    {
        unset ($new_dhcp_configuration['eth0']);
    }
	if ($dhcp_configuration['dhcp_server_eth1']=='on')
    {
        $new_dhcp_configuration['eth1']['start']=$dhcp_configuration['dhcp_start_eth1'];
        $new_dhcp_configuration['eth1']['end']=$dhcp_configuration['dhcp_end_eth1'];
        $new_dhcp_configuration['eth1']['expire']=$dhcp_configuration['dhcp_expire_eth1'];
    }
    else
    {
        unset ($new_dhcp_configuration['eth1']);
    }
	if ($dhcp_configuration['dhcp_server_eth2']=='on')
    {
        $new_dhcp_configuration['eth2']['start']=$dhcp_configuration['dhcp_start_eth2'];
        $new_dhcp_configuration['eth2']['end']=$dhcp_configuration['dhcp_end_eth2'];
        $new_dhcp_configuration['eth2']['expire']=$dhcp_configuration['dhcp_expire_eth2'];
    }
    else
    {
        unset ($new_dhcp_configuration['eth2']);
    }
    if ($dhcp_configuration['dhcp_server_wlan0']=='on')
    {
        $new_dhcp_configuration['wlan0']['start']=$dhcp_configuration['dhcp_start_wlan0'];
        $new_dhcp_configuration['wlan0']['end']=$dhcp_configuration['dhcp_end_wlan0'];
        $new_dhcp_configuration['wlan0']['expire']=$dhcp_configuration['dhcp_expire_wlan0'];
    }
    else
    {
        unset ($new_dhcp_configuration['wlan0']);
    }
    if ($dhcp_configuration['dhcp_server_wlan1']=='on')
    {
        $new_dhcp_configuration['wlan1']['start']=$dhcp_configuration['dhcp_start_wlan1'];
        $new_dhcp_configuration['wlan1']['end']=$dhcp_configuration['dhcp_end_wlan1'];
        $new_dhcp_configuration['wlan1']['expire']=$dhcp_configuration['dhcp_expire_wlan1'];
    }
    else
    {
        unset ($new_dhcp_configuration['br0']);
    }
	if ($dhcp_configuration['dhcp_server_br0']=='on')
    {
        $new_dhcp_configuration['br0']['start']=$dhcp_configuration['dhcp_start_br0'];
        $new_dhcp_configuration['br0']['end']=$dhcp_configuration['dhcp_end_br0'];
        $new_dhcp_configuration['br0']['expire']=$dhcp_configuration['dhcp_expire_br0'];
    }
    else
    {
        unset ($new_dhcp_configuration['br0']);
    }

    return $new_dhcp_configuration;
}
function save_dhcp_server($dhcp_configuration,$save_file='')
{
	global $base_plugin;

    if ($save_file=='')
    {
        $save_file=$base_plugin.'data/dnsmasq.more.conf';
    }
    
    $fp=fopen($save_file,"w");

	$save_configuration=update_dhcp($dhcp_configuration);
    foreach($save_configuration as $interface =>$interface_values)
	{
		fwrite($fp, "dhcp-range=".$interface.",".$interface_values['start'].",".$interface_values['end'].",".$interface_values['expire']."h\n");
	}
    fwrite($fp,"dhcp-leasefile=/var/tmp/dnsmasq.leases\n");
    fclose($fp);
}
?>